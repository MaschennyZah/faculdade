/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    
	    double [][] temperaturas = new double[3][4];
	    
		temperaturas[0][0] = 33;
		temperaturas[0][1] = 35;
		temperaturas[0][2] = 38;
		temperaturas[0][3] = 999;
		
		temperaturas[1][0] = 35;
		temperaturas[1][1] = 36;
		temperaturas[1][2] = 37.5;
		temperaturas[1][3] = 38.5;
		
		temperaturas[2][0] = 38.1;
		temperaturas[2][1] = 38.2;
		temperaturas[2][2] = 38.3;
		temperaturas[2][3] = 38.9;
		
		
	
		for (int i = 0; i < temperaturas.length; i++) {
		    System.out.println("Temperaturas da pessoa  "  + (i+1) + "  :  " );
		    
		    for (int j = 0; j < temperaturas[i].length; j ++) {
		        System.out.println(temperaturas[i][j] + " ");
		    }
		    System.out.println(" ");
		}
		
		for (int i = 0; i < temperaturas.length; i ++) {
		    double soma = 0;
		    
		    for (int j = 0; j < temperaturas[i].length; j++) {
		        soma = temperaturas[i][j] + soma;
		    }
		    
		    double media = soma/4;
		    System.out.println("Media da pessoa  " + (i+1) + " é : " + media);
		    
		   
		    }
		}

	}




